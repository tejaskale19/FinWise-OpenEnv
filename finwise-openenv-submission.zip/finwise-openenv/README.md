# 🏦 FinWise OpenEnv — Indian Portfolio Advisory Environment

> A real-world OpenEnv benchmark for training and evaluating LLM agents on Indian retail investor portfolio advisory tasks.

[![OpenEnv](https://img.shields.io/badge/OpenEnv-compatible-blue)](https://github.com/meta-pytorch/OpenEnv)
[![HF Space](https://img.shields.io/badge/🤗-Hugging%20Face%20Space-yellow)](https://huggingface.co/spaces)
[![Python 3.11](https://img.shields.io/badge/python-3.11-green)](https://www.python.org)
[![License: MIT](https://img.shields.io/badge/License-MIT-lightgrey)](LICENSE)

---

## 🎯 Motivation

Over 10 crore Indian retail investors make wealth management decisions guided by emotion, not data — leading to overconcentrated portfolios, missed SIP targets, and panic-selling during crashes.

**FinWise OpenEnv** provides a realistic benchmark where LLM agents can be trained and evaluated on the actual decisions a skilled wealth advisor makes: sector rebalancing, SIP optimization, mutual fund allocation, and crisis-mode capital protection — all grounded in NSE-listed equities and real Indian market scenarios.

This fills a genuine gap in the OpenEnv ecosystem: **no existing environment covers emerging-market retail portfolio management**.

---

## 🧠 Environment Overview

The agent acts as an AI wealth advisor. At each step it observes a complete investor portfolio snapshot and chooses one advisory action. The environment updates the portfolio and returns a dense reward signal reflecting progress toward the episode's financial objective.

### Interface

```
POST /reset  → PortfolioObservation (start new episode)
POST /step   → StepResult (observation + reward + done + info)
POST /state  → Dict (full internal state)
GET  /health → {"status": "ok"}
```

### Observation Space (`PortfolioObservation`)

| Field | Type | Description |
|-------|------|-------------|
| `cash_inr` | float | Available cash in INR |
| `total_portfolio_value_inr` | float | Total portfolio value |
| `stocks` | StockHoldings | 8 NSE stock values (TCS, INFY, WIPRO, HDFCBANK, ICICIBANK, HINDUNILVR, SUNPHARMA, RELIANCE) |
| `mutual_fund_value_inr` | float | Total MF allocation |
| `sip_monthly_inr` | float | Monthly SIP amount |
| `sector_exposure` | SectorExposure | Weights across IT, Banking, FMCG, Pharma, Energy |
| `risk_score` | float [0–1] | Current portfolio risk |
| `goal_progress` | float [0–1] | Progress toward target corpus |
| `nifty_trend` | str | bullish / bearish / sideways |
| `max_drawdown` | float | Current drawdown |
| `available_actions` | List[str] | Valid actions this step |

### Action Space (`PortfolioAction`)

| `action_type` | Required Params | Description |
|--------------|-----------------|-------------|
| `buy_stock` | asset, amount_inr | Buy a specific NSE stock |
| `sell_stock` | asset, amount_inr | Sell a specific NSE stock |
| `increase_sip` | amount_inr | Increase monthly SIP |
| `decrease_sip` | amount_inr | Decrease monthly SIP |
| `buy_mutual_fund` | amount_inr | Invest in mutual fund |
| `sell_mutual_fund` | amount_inr | Redeem mutual fund |
| `rebalance_sector` | asset, target_weight | Rebalance sector to target % |
| `hold` | — | No action this step |

Valid stocks: `TCS, INFY, WIPRO, HDFCBANK, ICICIBANK, HINDUNILVR, SUNPHARMA, RELIANCE`

Valid sectors: `IT, Banking, FMCG, Pharma, Energy`

---

## 📋 Tasks

### 🟢 Task 1 — Sector Diversification (Easy)

**Name:** `diversify_sector_easy`  
**Max Steps:** 8 | **Success Threshold:** 0.80

**Scenario:** An aggressive investor has 70% of their ₹5,00,000 portfolio locked in IT stocks (TCS, INFY, WIPRO). This creates massive concentration risk.

**Goal:** Reduce IT sector exposure to below 40% by selling IT holdings and diversifying into other sectors and/or mutual funds.

**Grader:** `score = f(IT_exposure)` — full score at ≤30%, success at ≤40%, partial credit down to >60%.

---

### 🟡 Task 2 — Retirement Goal Optimization (Medium)

**Name:** `retirement_goal_medium`  
**Max Steps:** 10 | **Success Threshold:** 0.75

**Scenario:** A 25-year-old moderate investor wants ₹1 Crore in 15 years. Current SIP is ₹3,000/month — far too low. Portfolio is underweighted in equity. Market is sideways.

**Goal:** Improve projected corpus probability to ≥80% of target via SIP increase, equity mutual fund allocation, and proper sector diversification.

**Grader:** `score = f(projected_corpus / target_corpus)` — bonuses for SIP increase, MF allocation, diversification.

---

### 🔴 Task 3 — Crash Protection (Hard)

**Name:** `crash_protection_hard`  
**Max Steps:** 12 | **Success Threshold:** 0.70

**Scenario:** CRISIS. Banking sector has crashed -22%. Investor has 45% banking exposure, portfolio is down 18%. They urgently need ₹2,00,000 liquid cash for a home loan down payment in 6 months. Long-term goal must still be maintained.

**Goal:** Balance three simultaneous objectives — reduce banking exposure, build cash liquidity, stop capital bleeding — while maintaining some growth allocation.

**Grader:** Composite of capital preservation (40%) + liquidity (35%) + banking reduction (25%).

---

## 💰 Reward Function

Dense reward computed every step (not just at episode end):

```
reward = diversification_delta × 0.30
       + corpus_growth_delta   × 0.30
       + risk_reduction_delta  × 0.20
       + liquidity_delta       × 0.20
       − overconcentration_penalty
       − churn_penalty
       − cash_depletion_penalty

range: [−1.0, 1.0]
```

Penalties applied for:
- Any sector > 60% weight (overconcentration)
- Excessive buy/sell activity (churn)
- Cash falling below ₹20,000 (depletion)

---

## 🚀 Setup & Usage

### Local Development

```bash
# Clone the repo
git clone https://github.com/your-username/finwise-openenv
cd finwise-openenv

# Install dependencies
pip install -r requirements.txt

# Set environment variables
cp .env.example .env
# Edit .env with your HF_TOKEN

# Run the server
python app.py
# Server starts at http://localhost:7860
```

### Run Inference

```bash
export HF_TOKEN=hf_xxxxxxxxxxxx
export API_BASE_URL=https://router.huggingface.co/v1
export MODEL_NAME=Qwen/Qwen2.5-72B-Instruct

python inference.py
```

### Docker

```bash
# Build
docker build -t finwise-openenv .

# Run
docker run -p 7860:7860 \
  -e HF_TOKEN=hf_xxxxxxxxxxxx \
  -e MODEL_NAME=Qwen/Qwen2.5-72B-Instruct \
  finwise-openenv
```

### API Usage

```python
import requests

BASE_URL = "http://localhost:7860"

# Start episode
resp = requests.post(f"{BASE_URL}/reset", json={"task_name": "diversify_sector_easy"})
data = resp.json()
session_id = data["session_id"]

# Take an action
resp = requests.post(f"{BASE_URL}/step", json={
    "session_id": session_id,
    "action_type": "sell_stock",
    "asset": "TCS",
    "amount_inr": 75000,
    "reasoning": "Reducing IT overexposure"
})
result = resp.json()
print(f"Reward: {result['reward']:.2f}, Done: {result['done']}")
```

### Python API

```python
from finwise_env import FinWiseEnv, PortfolioAction

env = FinWiseEnv(task_name="diversify_sector_easy")
obs = env.reset()

action = PortfolioAction(
    action_type="sell_stock",
    asset="TCS",
    amount_inr=75000,
    reasoning="Reducing IT sector overexposure"
)
result = env.step(action)
print(f"Reward: {result.reward:.2f}")
print(f"IT Exposure: {result.observation.sector_exposure.IT:.1%}")
```

---

## 📊 Baseline Scores

Baseline agent: `Qwen/Qwen2.5-72B-Instruct` via HF Inference Router

| Task | Difficulty | Baseline Score | Steps Used |
|------|-----------|----------------|-----------|
| `diversify_sector_easy` | Easy | 0.82 | 6 |
| `retirement_goal_medium` | Medium | 0.71 | 9 |
| `crash_protection_hard` | Hard | 0.58 | 12 |
| **Average** | | **0.70** | |

*Scores are reproducible: run `python inference.py` to regenerate.*

---

## 📁 Project Structure

```
finwise-openenv/
│
├── finwise_env/
│   ├── __init__.py      # Package exports
│   ├── models.py        # Typed Pydantic models (Observation, Action, Reward)
│   ├── env.py           # Main FinWiseEnv class (reset/step/state)
│   ├── tasks.py         # 3 task definitions with initial portfolios
│   └── graders.py       # Deterministic graders + reward function
│
├── inference.py         # MANDATORY: LLM agent baseline script
├── app.py               # FastAPI server (HF Space entrypoint)
├── openenv.yaml         # OpenEnv manifest
├── Dockerfile           # Container build
├── requirements.txt     # Python dependencies
├── README.md            # This file
└── .env.example         # Environment variable template
```

---

## 🔬 Judging Criteria Alignment

| Criterion | Weight | How FinWise Addresses It |
|-----------|--------|--------------------------|
| Real-world utility | 30% | Portfolio advisory is a task millions do daily |
| Task & grader quality | 25% | 3 tasks, clear difficulty, deterministic graders, 0–1 scores |
| Environment design | 20% | Dense reward, clean state, typed models, sensible episode bounds |
| Code quality & spec | 15% | Full OpenEnv spec, Docker, HF Space, typed Pydantic models |
| Creativity & novelty | 10% | First Indian NSE + SIP + MF OpenEnv environment |

---

## 📜 License

MIT License — see [LICENSE](LICENSE)

---

## 🙏 Acknowledgements

Built for the **Meta × PyTorch × Hugging Face OpenEnv Hackathon**.  
Powered by [OpenEnv](https://github.com/meta-pytorch/OpenEnv), [FastAPI](https://fastapi.tiangolo.com), and [Hugging Face](https://huggingface.co).
